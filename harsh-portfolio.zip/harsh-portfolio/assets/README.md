# assets/

Place your images, icons, and other static files here.

Examples:
- `assets/avatar.jpg`     — profile photo
- `assets/favicon.ico`    — browser tab icon
- `assets/og-image.png`   — Open Graph preview image for social sharing

Reference them in HTML like:
```html
<img src="assets/avatar.jpg" alt="Harsh Padher" />
```
